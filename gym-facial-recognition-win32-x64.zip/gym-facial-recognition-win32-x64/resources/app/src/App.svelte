<script>
    import ImageDownload from "./components/ImageDownload.svelte";
    import ImageRecognize from "./components/ImageRecognize.svelte";
    import { step } from "./stores.js";

    let currentStep = 0;

    step.subscribe((val) => {
        currentStep = val;
    });
</script>

<main>
    {#if currentStep == 0}
        <ImageDownload />
    {:else}
        <ImageRecognize />
    {/if}
</main>

<style>
</style>
