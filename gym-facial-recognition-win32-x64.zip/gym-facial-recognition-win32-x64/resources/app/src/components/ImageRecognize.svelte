<script>
    import { onMount } from "svelte";
    import { get } from "svelte/store";
    import { faceMatcherLabels } from "../stores.js";
    const FaceApi = require("face-api.js");
    const Axios = require("axios").default;

    let videoElem = null;
    const faceMatcher = new FaceApi.FaceMatcher(get(faceMatcherLabels));
    let lastFaceID = 0;

    onMount(() => {
        videoElem.addEventListener("play", async () => {
            setInterval(async () => {
                const detections = await FaceApi.detectAllFaces(
                    videoElem,
                    FaceApi.SsdMobilenetv1Options({ minConfidence: 0.8 })
                )
                    .withFaceLandmarks()
                    .withFaceDescriptors();
                detections.forEach(async (face) => {
                    let res = faceMatcher.findBestMatch(face.descriptor);
                    if (
                        res.distance <= 0.8 &&
                        res.label !== "unknown" &&
                        lastFaceID !== parseInt(res.label)
                    ) {
                        try {
                            const url = `${process.env.API_URL}/register-face/${res.label}`;
                            let response = await Axios({
                                url: `${url}`,
                                method: "POST",
                                timeout: 0,
                            });
                            // response = response.json();
                            response = response.data;
                            if (response.made_attendance == true) {
                                new Notification(`Attendance Registered`, {
                                    body: `Member with ${response.full_name} attended.`,
                                });
                            }
                            lastFaceID = parseInt(res.label);
                        } catch (error) {
                            console.log(error);
                        }
                    }
                });
            });
        });
        startVideo();
    });

    function startVideo() {
        navigator.getUserMedia(
            { video: {} },
            (stream) => (videoElem.srcObject = stream),
            (err) => alert(`Error: ${err}`)
        );
    }
</script>

<main>
    <section
        class="section is-flex has-background-white-ter is-align-items-center"
    >
        <div class="container">
            <div class="columns is-centered">
                <div class="column is-8">
                    <video width="100%" bind:this={videoElem} autoplay muted />
                </div>
            </div>
        </div>
    </section>
</main>

<style>
</style>
