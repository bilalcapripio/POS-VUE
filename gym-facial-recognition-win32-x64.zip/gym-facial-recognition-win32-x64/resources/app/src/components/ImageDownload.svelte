<script>
    import { onMount } from "svelte";
    import { faceMatcherLabels, step } from "../stores.js";

    const Fs = require("fs");
    const Axios = require("axios").default;
    const Path = require("path");
    const Extract = require("extract-zip");
    const FaceApi = require("face-api.js");
    const makeEta = require("simple-eta");

    FaceApi.env.monkeyPatch({
        Canvas: HTMLCanvasElement,
        CanvasRenderingContext2D: CanvasRenderingContext2D,
        Image: HTMLImageElement,
        ImageData: ImageData,
        Video: HTMLVideoElement,
        createCanvasElement: function () {
            return document.createElement("canvas");
        },
        createImageElement: function () {
            return document.createElement("img");
        },
    });

    let headingText = "Downloading Images...";
    let images = [];
    let learnedImages = 0;
    let currentImage = "";
    let imageElem = null;

    onMount(async () => {
        const url = `${process.env.API_URL}/download-faces`;
        const storagePath = Path.join(__dirname, "storage");
        const fileName = `${storagePath}/faces.zip`;
        if (await Fs.existsSync(fileName)) {
            await Fs.unlinkSync(fileName);
        }
        await downloadFile(url, fileName, process.env.FILE_DOWNLOAD_CODE);
        headingText = "Extracing Images...";
        await Extract(fileName, { dir: `${storagePath}/faces` });
        await Fs.unlinkSync(fileName);
        headingText = "Loading Models...";
        await loadModels();
        headingText = "Learning Faces...";
        await doLearnFaces(`${storagePath}/faces`);
        step.set(1);
    });

    async function downloadFile(url, fileName, code) {
        try {
            let response = await Axios({
                url: `${url}`,
                method: "POST",
                responseType: "blob",
                timeout: 0,
                data: {
                    code: code,
                },
            });
            let arrayBuffer = await response.data.arrayBuffer();
            await Fs.writeFileSync(fileName, Buffer.from(arrayBuffer));
        } catch (error) {
            console.log(error);
        }
    }

    async function loadModels() {
        const modelPath = Path.join(__dirname, "weights");
        await FaceApi.nets.ssdMobilenetv1.loadFromDisk(modelPath);
        await FaceApi.nets.faceRecognitionNet.loadFromDisk(modelPath);
        await FaceApi.nets.faceLandmark68Net.loadFromDisk(modelPath);
    }

    async function doLearnFaces(dir) {
        images = await Fs.readdirSync(dir);
        const labels = [];
        const eta = makeEta({ min: 0, max: images.length });

        for (let i = 0; i < images.length; i++) {
            const img = images[i];
            await changeImage(`storage/faces/${img}`);
            const detection = await FaceApi.detectSingleFace(imageElem)
                .withFaceLandmarks()
                .withFaceDescriptor();
            if (typeof detection !== "undefined") {
                labels.push(
                    new FaceApi.LabeledFaceDescriptors(
                        img.toLowerCase().replace(".jpg", ""),
                        [detection.descriptor]
                    )
                );
            }
            learnedImages++;
            eta.report(learnedImages);
            headingText = `Learning Faces (${learnedImages}/${
                images.length
            }) - Aprox. ${Math.round(eta.estimate())} seconds left`;
        }
        console.log(labels);
        faceMatcherLabels.set(labels);
    }

    async function changeImage(imgUrl) {
        currentImage = imgUrl;
        return new Promise((resolve, reject) => {
            imageElem.addEventListener("load", () => resolve(true));
            imageElem.addEventListener("error", () => reject(false));
        });
    }
</script>

<main>
    <section
        class="section is-flex has-background-white-ter is-align-items-center"
    >
        <div class="container">
            <div class="columns is-justify-content-center">
                <div class="column is-6">
                    <div class="card">
                        <header class="card-header">
                            <p class="card-header-title">{headingText}</p>
                        </header>
                        <div class="card-content">
                            {#if images.length == 0}
                                <progress
                                    class="progress is-primary"
                                    max="100"
                                />
                            {:else}
                                <progress
                                    class="progress is-primary"
                                    max={images.length}
                                    value={learnedImages}
                                />
                            {/if}
                            <img
                                bind:this={imageElem}
                                src={currentImage}
                                style="visibility: hidden;position:absolute;"
                                alt=""
                            />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<style>
</style>
