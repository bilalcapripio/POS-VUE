<?php
if(isset($_POST['mail'])){

    $to = "atiq.capripio@gmail.com";
    $subject = "My subject";
    $txt = "Hello world!";
    $headers = "From: atiq.capripio@gmail.com";
    
    if(wp_mail($to,$subject,$txt,$headers)){
    
        echo 'mail sent';
    
    }else{
        echo 'problem';
    }
    }
     ?>
    <form action="" method="post">
    <input type="submit" value="send" name="mail">
    </form>
<!-- // if(isset($_POST['mail'])){

// $to = "atiq.capripio@gmail.com";
// $subject = "My subject";
// $txt = "Hello world!";
// $headers = "From: bilal.capripio@gmail.com";

// if(mail($to,$subject,$txt,$headers)){

//     echo 'mail sent';

// }else{
//     echo 'problem';
// }
// }

// <!-- <form action="" method="post">
// <input type="submit" value="send" name="mail">
// </form> -->
<!-- // add_action('save_post_cp-mails','save_post');
// add_action('email_appointment_action','send_email_appointment');
// function save_post($post_id)
// {
//     // $contactform=WPCF7_ContactForm::get_current();
//     //     if($contactform->title == 'Contact form 1')
//     //     {
//             $two_days=30;
//             $post = get_post($post_id);
//             $args = array('email' => $post->post_title , 'title' => $post->post_content);
//             wp_schedule_single_event($two_days,'email_appointment_action', $args);
//             // return $schedule;
//             // }else{
//         //     return;
//         // }
// }

// function send_email_appointment($args)
// {
//     $text="<html><body><p>Your Appointment has been confirmed this date</p></body><html>";
//     $headers="From: '".get_bloginfo('admin_email')."'";
//     $subject="Appointment";
//     wp_mail($args['email'],$subject,$text,$headers);
//     // return $mail; -->
<!-- // } -->