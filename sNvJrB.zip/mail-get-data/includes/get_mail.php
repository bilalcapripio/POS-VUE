<?php


class BOOK_POST_TYPE
{

    private static $instance;

    public static function getInstance()
    {
        if (!self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct ()
    {
        add_action('init' , array($this,'cf7_init'));
        add_action('wpcf7_before_send_mail', array($this,'wpcf7_get_mail'));
        add_filter('post_row_actions', array($this, 'remove_row_actions'));
        // add_action('add_meta_boxes_cp-mails',array($this,'add_meta_boxes'));
        add_action('save_post_cp-mails',array($this,'save_post'));
        add_action('email_appointment_action',array($this,'send_email_appointment'));

    }

    function cf7_init()
    {
        $labels=array(
            'name'=> _x('Mails','post type plural name','cp-get-mail-data'),
            'singular_name ' => _x('Mail','post type singular name','cp-get-mail-data'),
            'menu_name ' => _x('Mails','admin menu','cp-get-mail-data'),
            'all_items' => __('All Mails','cp-get-mail-data'),
            'not_found' => __('Mails Not found','cp-get-mail-data'),
            'not_found_in_trash'=> __('Mails Not found in trash','cp-get-mail-data'),
            'search_items' => __('Search Mails', 'cp-get-mail-data'),
            'add_new' => false,
        );

        $args=array(
            'labels' => $labels,
            'public' => false,
            'publicly_queryable' => false,
            'rewrite' => false,
            'query_var' => false,
            'show_ui' => true,
            'show_in_menu' => true,
            'menu_icon' => 'dashicons-email-alt',
        );

        register_post_type('cp-mails',$args);

    }

    function wpcf7_get_mail($post_id)
    {
        
        $submission=WPCF7_Submission::get_instance();
        
        $data=$submission->get_posted_data();
        $name=$data['your-name'];
        $email=$data['your-email'];
        $subject=$data['your-subject'];
        $message=$data['your-message'];
        $args=array(
                'post_status'=>'publish',
                'post_type'=>'cp-mails',
                'orderby' => 'date',
                'order' => 'DESC',
                'post_title'=>$email,
                'post_content'=>$name
            );

        wp_insert_post($args);

    }

    public function remove_row_actions($actions)
    {
        if( get_post_type() == 'cp-mails' )
        {
            $actions[]='<a href="#" class="row-actions">Send Mail</a>';
            unset($actions['edit']);
            unset( $actions['inline hide-if-no-js']);
            return $actions;
        
        }else{
            return $actions;
        }
    }

    function save_post($post_id)
    {
        $two_days=time();
        $post = get_post($post_id);
        $args = array('email' => $post->post_title , 'title' => $post->post_content);
        wp_schedule_single_event($two_days,'email_appointment_action', $args);
    }

    function send_email_appointment($args)
    {
        $text="Your Appointment has been confirmed this date";  
        $headers="From: '".get_bloginfo('admin_email')."'";
        $subject="Appointment";
        wp_mail($args,$subject,$text,$headers);
    }
}
return BOOK_POST_TYPE::getInstance();