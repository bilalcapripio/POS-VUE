<?php

/*
 * Plugin Name: Mail
 * Description: mail data get
 * Author: Capripio
 * Author URI: http://capripio.com
 * Plugin URI: http://capripio.com/epub-creator
 * Version: 0.0.1
 */

define('mail_get_data',dirname(__FILE__));

if (!function_exists('dump')) {
    function dump($value)
    {
        echo "<pre>";
        var_dump($value);
        echo "</pre>";
    }
}
if (!function_exists('dd')) {
    function dd($value)
    {
        dump($value);
        die();
    }
}
require_once mail_get_data . '/includes/get_mail.php';
// require_once mail_get_data . '/includes/test.php';
